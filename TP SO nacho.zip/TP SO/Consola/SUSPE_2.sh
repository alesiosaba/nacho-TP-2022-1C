#!/bin/bash

make
clear

./Consola.out ./cfg/SUSPE_2 1