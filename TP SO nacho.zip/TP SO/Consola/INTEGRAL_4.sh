#!/bin/bash

make
clear

./Consola.out ./cfg/INTEGRAL_4 2048