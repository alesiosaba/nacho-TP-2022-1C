#!/bin/bash

make
clear

./Consola.out ./cfg/PLANI_1 1