#!/bin/bash

make
clear

./Consola.out ./cfg/BASE_1 1