#!/bin/bash

make
clear

./Consola.out ./cfg/INTEGRAL_1 2048