#!/bin/bash

make
clear

./Consola.out ./cfg/INTEGRAL_2 2048