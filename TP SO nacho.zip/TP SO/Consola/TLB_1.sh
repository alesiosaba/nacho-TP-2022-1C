#!/bin/bash

make
clear

./Consola.out ./cfg/TLB_1 2048