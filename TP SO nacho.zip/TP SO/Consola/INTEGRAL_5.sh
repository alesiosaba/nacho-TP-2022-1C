#!/bin/bash

make
clear

./Consola.out ./cfg/INTEGRAL_5 2048