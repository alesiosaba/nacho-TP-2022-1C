#!/bin/bash

make
clear

./Consola.out ./cfg/SUSPE_1 1