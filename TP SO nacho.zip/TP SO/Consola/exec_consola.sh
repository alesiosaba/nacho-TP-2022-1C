#!/bin/bash

make
clear

./Consola.out ./cfg/proceso1.txt 1
