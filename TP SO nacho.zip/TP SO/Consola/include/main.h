#ifndef HEADERS_MAIN_H_
#define HEADERS_MAIN_H_

#include <stdio.h>
#include <stdbool.h>
#include "../include/config.h"
#include "../include/leer_codigo.h"
#include "../../shared/include/shared_log.h" 
#include "../../shared/include/shared_utils.h"
#include "../../shared/include/shared_mensajes.h"
#include "../../shared/include/shared_servidor.h"

#endif /* HEADERS_MAIN_H_ */
