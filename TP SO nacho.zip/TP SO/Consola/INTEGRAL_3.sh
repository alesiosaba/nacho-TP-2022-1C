#!/bin/bash

make
clear

./Consola.out ./cfg/INTEGRAL_3 2048