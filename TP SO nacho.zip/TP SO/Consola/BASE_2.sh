#!/bin/bash

make
clear

./Consola.out ./cfg/BASE_2 1