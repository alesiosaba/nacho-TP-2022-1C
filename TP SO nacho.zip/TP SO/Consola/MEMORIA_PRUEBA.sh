#!/bin/bash

make
clear

./Consola.out ./cfg/MEMORIA_PRUEBA 4096