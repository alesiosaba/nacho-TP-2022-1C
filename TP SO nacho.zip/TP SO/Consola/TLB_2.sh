#!/bin/bash

make
clear

./Consola.out ./cfg/TLB_2 2048