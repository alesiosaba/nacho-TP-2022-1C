#!/bin/bash

make
clear

./Consola.out ./cfg/SUSPE_3 1