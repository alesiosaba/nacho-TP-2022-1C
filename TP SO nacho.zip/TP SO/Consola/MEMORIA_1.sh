#!/bin/bash

make
clear

./Consola.out ./cfg/MEMORIA_1 4096