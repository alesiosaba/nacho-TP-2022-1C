#!/bin/bash

make
./Kernel.out ./cfg/plani.config