#!/bin/bash

make
./Kernel.out ./cfg/base.config