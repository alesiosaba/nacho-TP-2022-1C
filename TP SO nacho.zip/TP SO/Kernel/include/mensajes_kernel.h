#ifndef HEADERS_MENSAJES_KERNEL_H_
#define HEADERS_MENSAJES_KERNEL_H_

#include <stdio.h>
#include <commons/log.h>
#include "../../shared/include/shared_mensajes.h"

void gestionar_mensaje(t_paquete*, int, t_log);

#endif /* HEADERS_MENSAJES_KERNEL_H_ */