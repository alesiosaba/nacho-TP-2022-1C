#!/bin/bash

make
./Kernel.out ./cfg/memoria-tlb.config