#!/bin/bash

make
./Kernel.out ./cfg/suspe.config