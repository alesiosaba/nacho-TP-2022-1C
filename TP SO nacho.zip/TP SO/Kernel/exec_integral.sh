#!/bin/bash

make
./Kernel.out ./cfg/integral.config