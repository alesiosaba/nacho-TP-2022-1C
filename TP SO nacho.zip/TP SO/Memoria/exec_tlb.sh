#!/bin/bash

make
./Memoria.out ./cfg/tlb.config