#!/bin/bash

make
./Memoria.out ./cfg/integral.config