#!/bin/bash

make
./Memoria.out ./cfg/base-plani-suspe.config