#ifndef HEADERS_MAIN_H_
#define HEADERS_MAIN_H_

#include <stdio.h>
#include "./config.h"
#include "./server.h"
#include "./Disco.h"
#include "./crear_estructuras.h"
#include "../../shared/include/shared_log.h"
#include "../../shared/include/shared_utils.h"
#include "../../shared/include/shared_mensajes.h"
#include "../../shared/include/shared_servidor.h"


#endif /* HEADERS_MAIN_H_ */
