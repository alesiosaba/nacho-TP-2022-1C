#!/bin/bash

make
./Memoria.out ./cfg/memoria.config