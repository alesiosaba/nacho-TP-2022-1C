#ifndef SHARED_CONFIG
#define SHARED_CONFIG

#include <commons/config.h>
#include <stdio.h>

t_config* iniciar_config(char*);
void destruir_config(t_config*);

#endif