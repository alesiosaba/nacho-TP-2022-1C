#!/bin/bash

make
./CPU.out ./cfg/integral.config