#!/bin/bash

make
./CPU.out ./cfg/memoria.config