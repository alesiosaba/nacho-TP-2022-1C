#!/bin/bash

make
./CPU.out ./cfg/tlb.config