#!/bin/bash

make
./CPU.out ./cfg/base-plani-suspe.config