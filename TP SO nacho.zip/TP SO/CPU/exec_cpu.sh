#!/bin/bash

make clean
make

./CPU.out
